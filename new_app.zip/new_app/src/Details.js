import React from 'react';

const Details = ({ users}) => {
    console.log(users);
  return (
    <div>
      <h2>Student Details</h2>
      {/* <ul>
        {users.map((user)=>(
            <li>
                <h2>{user.name}</h2>
                {user.email}
            </li>
        ))}
      </ul> */}
      
         <table className='border-2 w-full'>
         <thead>
             <tr className="border-2 border-gray-200">
             <th style={{ border: '1px solid black' }}>Id</th>
                 <th>Name</th>
                 <th>Email</th>
                 <th>Age</th>
                 <th>City</th>
                 <th>Delete</th>
             </tr>
         </thead>
         {users.map((user,id)=>{ return (
         <tbody>
             <tr key={id} className="border-2 border-gray-200">
                <p>{user.id}</p>
                <td>{user.name}</td>
                <td>{user.email}</td>
                <td>{user.age}</td>
                <td>{user.city}</td>
                
             </tr>
         </tbody>

)})}
      </table>
      
    </div>
  );
};

export default Details;
