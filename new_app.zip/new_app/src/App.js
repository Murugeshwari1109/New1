import { Routes, Route, useNavigate } from 'react-router-dom';
import './App.css';
import Form from './Form';
import { useEffect, useState } from 'react';
import Details from './Details';
import axios from 'axios';
import APIRequest from './API/APIRequest';

function App() {
  const url = "http://localhost:3500/students";
  const [users, setUsers] = useState([]);
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    age: '',
    city: ''
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(url);
        setUsers(response.data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const user_id=users.length?users[users.length-1].id+1:1 ;
    const newUser = {id:user_id, name: formData.name, email: formData.email, age: formData.age, city: formData.city };
    
    try {
      const result = await APIRequest.post('/students', newUser);
      setUsers([...users, result.data]);
      setFormData({ name: '', email: '', age: '', city: '' });
      navigate('/detail');
    } catch (error) {
      console.error("Error adding user:", error);
    }
  }

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  }


  return (
    <div className="App">
      <header className='flex justify-between bg-blue-200 p-[1%]'>
        <h1 className="text-2xl font-sans bg-blue-200">Welcome</h1>
        <div className='flex mr-[5%]'>
          <button className='bg-[#003554] text-white text-lg mr-[6%] rounded w-28 h-10' onClick={() => navigate('/detail')}>
            View
          </button>
          <button className='bg-[#003554] text-white text-lg rounded w-28 h-10' onClick={() => navigate('/')}>
            Back
          </button>
        </div>
      </header>

      <Routes>
        <Route path="/" element={
          <Form
            formData={formData}
            handleSubmit={handleSubmit}
            handleChange={handleChange}
          />
        } />
        <Route path="/detail" element={<Details users={users}  />} />
      </Routes>
    </div>
  );
}

export default App;
