import React from 'react'

const Form = ({formData,handleSubmit,handleChange}) => {
  return (
    <div className='flex justify-center item-center mt-[5%]'>
        <form className='flex flex-col justify-center item-center bg-[#bbd0ff] w-1/2 h-[50] p-10 rounded-md shadow-md' onSubmit={handleSubmit}>

            <div className='mb-4 '>
                <label className="text-2xl" for="name">Name:</label>
                <input className='p-3 ml-4 border-2 border-gray-500 rounded' type="text" id="name" name="name" value={formData.name} onChange={handleChange} required/>
            </div>
            <div className='mb-5'>
                <label className="text-2xl" for="email">Email:</label>
                <input className='p-3 ml-5 border-2 border-gray-500 rounded' type="email" id="email" name="email" value={formData.email} onChange={handleChange} required/>
            </div>
            <div className='mb-5'>
                <label className="text-2xl" for="age">Age:</label>
                <input className='p-3 ml-8 border-2 border-gray-500 rounded'  type="number" id="age" name="age" value={formData.age} onChange={handleChange} required/>
            </div>
            <div className='mb-5'>
                <label className="text-2xl" for="city">City:</label>
                <input className='p-3 ml-8 border-2 border-gray-500 rounded'  type="text" id="city" name="city" value={formData.city} onChange={handleChange} required/>
            </div>
            <div className='justify-center  pb-9 '>
                <button className="mt-5 bg-[#003554] rounded text-white p-2 w-[30%]" type="submit" >Submit</button>
            </div>
        </form>

    </div>
  )
}

export default Form